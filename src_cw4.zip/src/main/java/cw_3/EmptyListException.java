package cw_3;

public class EmptyListException extends RuntimeException {
}
