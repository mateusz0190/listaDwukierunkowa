package cw_15;


public class MatUtils {

    public static long factorial_i(int n) {
        if (n < 0) {
            throw new IllegalArgumentException();
        }
        long result = 1;
        if (n == 0) {
            return result;
        } else {
            while (n > 0) {
                result *= n;
                n--;
            }
        }
        return result;
    }

    public static long factorial_r(int n) {
        long result;
        if (n < 0) {
            throw new IllegalArgumentException();
        } else if (n <= 1) {
            return 1;
        } else {
            result = n * factorial_r(n - 1);
            return result;
        }


    }
}
