package cw_15;

public interface Mat {
    long factorial_i(int n);

    long factorial_r(int n);
}
