package cw_4;


import cw_3.EmptyListException;
import cw_3.SimpleList;

public class TwoWayLinkedList implements SimpleList {

    private NodeTwoWay head = null;
    private NodeTwoWay tail = null;
    private int size;


    @Override
    public void addFirst(int element) {
        if (head == null && tail == null) {
            NodeTwoWay nodeTwoWay = new NodeTwoWay(element, null, null);
            head = nodeTwoWay;
            tail = nodeTwoWay;
        } else {
            NodeTwoWay nodeTwoWay = new NodeTwoWay(element, null, head);
            head = nodeTwoWay;
        }
        size++;
    }

    @Override
    public void addLast(int element) {
        if (head == null) {
            addFirst(element);
        } else {
            NodeTwoWay nodeTwoWay = new NodeTwoWay(element, tail, null);
            tail.next(nodeTwoWay);
            tail = nodeTwoWay;
            size++;
        }

    }

    @Override
    public void add(int element, int index) {
        NodeTwoWay current = head;
        if (index > size) {
            throw new IndexOutOfBoundsException();
        } else if (head == null || index == 0) {
            addFirst(element);
        } else if (index == size) {
            addLast(element);
        } else {
            if (index > ((size - 1) / 2)) {
                current = tail;
                for (int i = size - 1; i >= index; i--) {
                    current = current.previous();

                }
                NodeTwoWay nodeTwoWay = new NodeTwoWay(element, current, current.next());
                current.next(nodeTwoWay);
                nodeTwoWay.next().previous(nodeTwoWay);
//                while (tail.hasNext()) {
//                    tail = tail.next();
//                }
                //size++;
            } else {
                for (int i = 0; i <= index; i++) {
                    current = current.next();
                }
                NodeTwoWay nodeTwoWay = new NodeTwoWay(element, current.previous(), current);
                current.previous(nodeTwoWay);
                nodeTwoWay.previous().next(nodeTwoWay);
//                while (head.hasPrevious()) {
//                    head = head.previous();
//                }


            }
            size++;


        }
    }

    @Override
    public int removeFirst() {
        int result;
        if (head == null || size < 1) {
            throw new EmptyListException();
        } else if (size == 1) {
            NodeTwoWay current = head;
            result = current.value();
            head = null;
            size--;
            return result;
        }

        NodeTwoWay current = head;
        result = current.value();
        head = current.next();
        size--;
        head.previous(null);
        return result;
    }

    @Override
    public int removeLast() {
        if (head == null) {
            throw new EmptyListException();
        } else if (size == 1) {
            return removeFirst();
        } else {
            int result;
            NodeTwoWay current = tail;
            result = current.value();
            tail = current.previous();
            size--;
            tail.next(null);
            return result;
        }

    }

    @Override
    public int remove(int index) {
        NodeTwoWay current = head;
        if (head == null || size < 1) {
            throw new EmptyListException();
        } else if (index >= size) {
            throw new IndexOutOfBoundsException();
        } else if (head == null || index == 0) {
            return removeFirst();
        } else if (index == (size-1)){
            return removeLast();
        } else {
            if (index > ((size - 1) / 2)) {
                current = tail;
                for (int i = size - 1; i > index; i--) {
                    current = current.previous();
                }
            } else {
                for (int i = 0; i < index; i++) {
                    current = current.next();
                }
            }
            int result = current.value();
            current.previous().next(current.next());
            current.next().previous(current.previous());
            size--;

            return result;
        }
    }

    @Override
    public int get(int index) {
        if (index < 0) {
            throw new IndexOutOfBoundsException();
        } else if (head == null) {
            throw new EmptyListException();
        } else if (index == 0) {
            return head.value();
        }
        NodeTwoWay current = head;
        if (index > ((size - 1) / 2)) {
            current = tail;
            for (int i = size - 1; i > index; i--) {
                current = current.previous();

            }

            return current.value();
        } else {
            current = head;
            for (int i = 0; i < index; i++) {
                current = current.next();

            }

            return current.value();
        }

    }

    @Override
    public boolean contains(int element) {

        NodeTwoWay current = head;
        if (head == null) {
            return false;
        }
        if (current.value() == element || tail.value() == element) {
            return true;
        } else {
            while (current != tail) {
                if (current.value() == element) {
                    return true;
                } else {
                    current = current.next();
                }
            }
        }


        return false;
    }

    @Override
    public int size() {
        return this.size;
    }
}
