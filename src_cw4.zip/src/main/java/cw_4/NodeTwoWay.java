package cw_4;

public class NodeTwoWay {
    private NodeTwoWay next;
    private NodeTwoWay previous;
    private int value;

    public NodeTwoWay(int value, NodeTwoWay previous, NodeTwoWay next) {
        this.next = next;
        this.previous = previous;
        this.value = value;
    }

    public int value() {
        return value;
    }

    public void previous(NodeTwoWay previous) {
        this.previous = previous;
    }

    public void next(NodeTwoWay next) {
        this.next = next;
    }

    public NodeTwoWay previous() {
        return previous;
    }

    public NodeTwoWay next() {
        return next;
    }

    public boolean hasPrevious() {
        return previous != null;
    }

    public boolean hasNext() {
        return next != null;
    }


}
