package cw_15;

//import jdk.internal.jline.internal.TestAccessible;
import org.junit.Test;

import static org.junit.Assert.*;

public class MatUtilsTest {

    @Test
    public void factorial_i() {

        long result = MatUtils.factorial_i(10);
        assertEquals(3628800, result);
    }
    @Test
    public void factorial_i_ValueZero() {

        long result = MatUtils.factorial_i(0);
        assertEquals(1, result);
    }
    @Test (expected = NullPointerException.class)
    public void factorial_i_negativeValue() {
        long result = MatUtils.factorial_i(-2);
        //assertEquals(1, result);
    }

    @Test
    public void factorial_r() {

        long result = MatUtils.factorial_r(10);
        assertEquals(3628800, result);
    }
    @Test
    public void factorial_r_ValueZero() {

        long result = MatUtils.factorial_r(0);
        assertEquals(1, result);
    }
    @Test (expected = NullPointerException.class)
    public void factorial_r_negativeValue() {
        long result = MatUtils.factorial_r(-2);

    }

}